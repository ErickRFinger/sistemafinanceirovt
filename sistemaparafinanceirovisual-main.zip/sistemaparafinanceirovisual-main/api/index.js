import app from '../backend/server.js';
export default app;
